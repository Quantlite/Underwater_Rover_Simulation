#!/usr/bin/env bash
# Captures the UI-only demo sequence from the current X11 desktop.
set -euo pipefail
cd "$(dirname "$0")"

if [[ -z "${DISPLAY:-}" ]]; then
  echo "DISPLAY is not set. Run this script from an active Linux desktop session." >&2
  exit 1
fi
if ! command -v ffmpeg >/dev/null 2>&1; then
  echo "ffmpeg is required. Install it with: sudo apt install ffmpeg" >&2
  exit 1
fi

OUTPUT="${1:-Coratia_ROV_Walkthrough.mp4}"
RESOLUTION="$(xdpyinfo -display "$DISPLAY" 2>/dev/null | awk '/dimensions:/ {print $2; exit}')"
if [[ -z "$RESOLUTION" ]]; then
  echo "Could not determine X11 display size." >&2
  exit 1
fi

python3 -m rov_ground_station --demo >/tmp/coratia_rov_demo.log 2>&1 &
APP_PID=$!
cleanup() {
  kill "$APP_PID" 2>/dev/null || true
  wait "$APP_PID" 2>/dev/null || true
}
trap cleanup EXIT
sleep 0.3
ffmpeg -y -f x11grab -framerate 20 -video_size "$RESOLUTION" -i "$DISPLAY" \
  -t 27 -an -c:v libx264 -preset veryfast -crf 22 -pix_fmt yuv420p "$OUTPUT"
echo "Saved walkthrough: $OUTPUT"
echo "Check that the map panel shows live OSM tiles before submitting the video."
