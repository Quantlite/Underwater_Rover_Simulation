"""Threaded CSV telemetry writer to keep disk I/O off the UI loop."""
from __future__ import annotations

import csv
from datetime import datetime
from pathlib import Path
from queue import Queue, Empty
from threading import Event, Thread
from typing import Optional

from .simulator import Telemetry


class TelemetryLogger:
    def __init__(self, output_dir: str | Path = "logs") -> None:
        self.output_dir = Path(output_dir)
        self._queue: Queue[Telemetry | None] = Queue(maxsize=5000)
        self._stop = Event()
        self._thread: Optional[Thread] = None
        self.path: Optional[Path] = None
        self.dropped_rows = 0

    @property
    def active(self) -> bool:
        return self._thread is not None and self._thread.is_alive()

    def start(self) -> Path:
        if self.active:
            return self.path  # type: ignore[return-value]
        self.output_dir.mkdir(parents=True, exist_ok=True)
        stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        self.path = self.output_dir / f"rov_telemetry_{stamp}.csv"
        self._stop.clear()
        self._thread = Thread(target=self._writer, name="rov-csv-writer", daemon=True)
        self._thread.start()
        return self.path

    def log(self, telemetry: Telemetry) -> None:
        if not self.active:
            return
        try:
            self._queue.put_nowait(telemetry)
        except Exception:
            self.dropped_rows += 1

    def stop(self) -> None:
        if not self.active:
            return
        self._stop.set()
        try:
            self._queue.put_nowait(None)
        except Exception:
            pass
        self._thread.join(timeout=2.0)  # type: ignore[union-attr]
        self._thread = None

    def _writer(self) -> None:
        assert self.path is not None
        columns = [
            "elapsed_s", "armed", "mode", "roll_deg", "pitch_deg", "yaw_deg",
            "depth_m", "battery_v", "north_m", "east_m", "surge_mps", "sway_mps",
            "heave_mps", "yaw_rate_dps", "target_depth_m", "target_heading_deg",
            "thruster_surge", "thruster_sway", "thruster_heave", "thruster_yaw",
            "failsafe_active", "current_enabled", "current_speed_mps", "current_heading_deg",
        ]
        with self.path.open("w", newline="", encoding="utf-8") as handle:
            writer = csv.DictWriter(handle, fieldnames=columns)
            writer.writeheader()
            while not self._stop.is_set() or not self._queue.empty():
                try:
                    item = self._queue.get(timeout=0.1)
                except Empty:
                    continue
                if item is None:
                    continue
                values = item.__dict__.copy()
                values["mode"] = item.mode.value
                values["thruster_surge"], values["thruster_sway"], values["thruster_heave"], values["thruster_yaw"] = item.thrusters
                values.pop("thrusters", None)
                writer.writerow(values)
                self._queue.task_done()
            handle.flush()
