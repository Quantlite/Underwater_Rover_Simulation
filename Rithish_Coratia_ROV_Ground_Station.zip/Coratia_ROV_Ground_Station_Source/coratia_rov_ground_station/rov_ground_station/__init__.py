"""Coratia ROV Telemetry Ground Station."""
__version__ = "1.0.0"
