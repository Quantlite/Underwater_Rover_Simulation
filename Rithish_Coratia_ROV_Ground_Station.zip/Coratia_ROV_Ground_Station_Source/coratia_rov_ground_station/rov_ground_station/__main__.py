from __future__ import annotations
import argparse
from .app import launch


def main() -> None:
    parser = argparse.ArgumentParser(description="Coratia ROV Telemetry Ground Station")
    parser.add_argument("--demo", action="store_true", help="play a short UI demonstration sequence")
    args = parser.parse_args()
    launch(demo=args.demo)


if __name__ == "__main__":
    main()
