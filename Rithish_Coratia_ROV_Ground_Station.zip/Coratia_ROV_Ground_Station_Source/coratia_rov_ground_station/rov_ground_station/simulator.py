"""Deterministic, hardware-free ROV dynamics and safety model.

The model uses a deliberately small 4-axis control surface:
  surge: forward/reverse, sway: right/left, heave: down/up, yaw: turn.
Depth is positive down. Heading is degrees clockwise from north.
"""
from __future__ import annotations

from collections import deque
from dataclasses import dataclass
from enum import Enum
import math
from typing import Deque, Iterable, Tuple


class Mode(str, Enum):
    MANUAL = "MANUAL"
    DEPTH_HOLD = "DEPTH HOLD"
    HEADING_HOLD = "HEADING HOLD"


@dataclass(frozen=True)
class Telemetry:
    elapsed_s: float
    armed: bool
    mode: Mode
    roll_deg: float
    pitch_deg: float
    yaw_deg: float
    depth_m: float
    battery_v: float
    north_m: float
    east_m: float
    surge_mps: float
    sway_mps: float
    heave_mps: float
    yaw_rate_dps: float
    target_depth_m: float
    target_heading_deg: float
    thrusters: Tuple[float, float, float, float]
    failsafe_active: bool
    current_enabled: bool
    current_speed_mps: float
    current_heading_deg: float


class ROVSimulator:
    """Small 6-DOF-inspired ROV simulator with 4-axis operator commands.

    It is intentionally a simulation, not a hydrodynamically accurate vehicle
    model. Dynamics, response delay, drag, and hold controllers are kept
    explicit so they are easy to explain and test.
    """

    MAX_DEPTH_M = 50.0
    MANUAL_TIMEOUT_S = 1.0
    RESPONSE_DELAY_S = 0.12
    RESPONSE_TAU_S = 0.16
    BATTERY_START_V = 16.8
    BATTERY_MIN_V = 12.0

    def __init__(self) -> None:
        self.elapsed_s = 0.0
        self.armed = False
        self.mode = Mode.MANUAL
        self.roll_deg = 0.0
        self.pitch_deg = 0.0
        self.yaw_deg = 276.0
        self.depth_m = 2.4
        self.battery_v = self.BATTERY_START_V
        self.north_m = 0.0
        self.east_m = 0.0

        self.surge_mps = 0.0
        self.sway_mps = 0.0
        self.heave_mps = 0.0
        self.yaw_rate_dps = 0.0

        self.target_depth_m = self.depth_m
        self.target_heading_deg = self.yaw_deg
        self._manual_command = (0.0, 0.0, 0.0, 0.0)
        self._thrusters = (0.0, 0.0, 0.0, 0.0)
        self._command_history: Deque[tuple[float, tuple[float, ...]]] = deque(maxlen=100)
        self._last_input_at = 0.0
        self.failsafe_active = False

        self.current_enabled = True
        self.current_speed_mps = 0.16
        self.current_heading_deg = 228.0

    @staticmethod
    def _clamp(value: float, low: float = -1.0, high: float = 1.0) -> float:
        return max(low, min(high, float(value)))

    @staticmethod
    def _wrap_heading(degrees: float) -> float:
        return float(degrees) % 360.0

    @staticmethod
    def heading_error(target: float, current: float) -> float:
        """Signed shortest heading error in [-180, 180)."""
        return (float(target) - float(current) + 180.0) % 360.0 - 180.0

    @property
    def thrusters(self) -> Tuple[float, float, float, float]:
        return self._thrusters

    def arm(self, now: float | None = None) -> tuple[bool, str]:
        if self.battery_v <= self.BATTERY_MIN_V + 0.2:
            return False, "ARM BLOCKED: battery below safe threshold"
        self.armed = True
        self._last_input_at = self.elapsed_s if now is None else float(now)
        self._manual_command = (0.0, 0.0, 0.0, 0.0)
        self._command_history.clear()
        self._thrusters = (0.0, 0.0, 0.0, 0.0)
        self.failsafe_active = False
        return True, "Vehicle armed"

    def disarm(self) -> None:
        """Immediate safety action: all thrust is zero in the same call."""
        self.armed = False
        self._manual_command = (0.0, 0.0, 0.0, 0.0)
        self._command_history.clear()
        self._thrusters = (0.0, 0.0, 0.0, 0.0)
        self.failsafe_active = False

    def set_mode(self, mode: Mode, now: float | None = None) -> None:
        self.mode = Mode(mode)
        self._manual_command = (0.0, 0.0, 0.0, 0.0)
        self._command_history.clear()
        self._thrusters = (0.0, 0.0, 0.0, 0.0)
        self.failsafe_active = False
        self._last_input_at = self.elapsed_s if now is None else float(now)
        if self.mode == Mode.DEPTH_HOLD:
            self.target_depth_m = self.depth_m
        elif self.mode == Mode.HEADING_HOLD:
            self.target_heading_deg = self.yaw_deg

    def set_target_depth(self, depth_m: float) -> None:
        depth = float(depth_m)
        if not math.isfinite(depth) or not 0.0 <= depth <= self.MAX_DEPTH_M:
            raise ValueError(f"Target depth must be between 0 and {self.MAX_DEPTH_M:g} m")
        self.target_depth_m = depth

    def set_target_heading(self, heading_deg: float) -> None:
        heading = float(heading_deg)
        if not math.isfinite(heading):
            raise ValueError("Target heading must be a finite number")
        self.target_heading_deg = self._wrap_heading(heading)

    def set_manual_input(
        self,
        surge: float = 0.0,
        sway: float = 0.0,
        heave: float = 0.0,
        yaw: float = 0.0,
        now: float | None = None,
    ) -> None:
        """Update the four manual axes and refresh the one-second watchdog."""
        self._manual_command = (
            self._clamp(surge), self._clamp(sway), self._clamp(heave), self._clamp(yaw)
        )
        self._last_input_at = self.elapsed_s if now is None else float(now)
        self.failsafe_active = False

    def set_current(self, enabled: bool) -> None:
        self.current_enabled = bool(enabled)

    def _delayed_command(self, now: float, desired: tuple[float, ...]) -> tuple[float, ...]:
        self._command_history.append((now, desired))
        cutoff = now - self.RESPONSE_DELAY_S
        delayed = (0.0, 0.0, 0.0, 0.0)
        for timestamp, command in self._command_history:
            if timestamp <= cutoff:
                delayed = command
            else:
                break
        while len(self._command_history) > 2 and self._command_history[1][0] <= cutoff:
            self._command_history.popleft()
        return delayed

    def _controller_command(self, now: float) -> tuple[float, float, float, float]:
        if not self.armed:
            self.failsafe_active = False
            return (0.0, 0.0, 0.0, 0.0)

        if self.mode == Mode.MANUAL:
            if now - self._last_input_at >= self.MANUAL_TIMEOUT_S:
                self.failsafe_active = True
                self._manual_command = (0.0, 0.0, 0.0, 0.0)
                # The watchdog is a hard output cut, not a slow ramp-down.
                self._thrusters = (0.0, 0.0, 0.0, 0.0)
                self._command_history.clear()
                return (0.0, 0.0, 0.0, 0.0)
            return self._manual_command

        self.failsafe_active = False
        if self.mode == Mode.DEPTH_HOLD:
            depth_error = self.target_depth_m - self.depth_m
            # Bounded PD hold: target depth is positive down.
            heave = self._clamp(0.75 * depth_error - 0.85 * self.heave_mps)
            return (0.0, 0.0, heave, 0.0)

        heading_error = self.heading_error(self.target_heading_deg, self.yaw_deg)
        yaw_command = self._clamp(0.035 * heading_error - 0.10 * self.yaw_rate_dps)
        return (0.0, 0.0, 0.0, yaw_command)

    def step(self, dt: float, now: float | None = None) -> Telemetry:
        """Advance dynamics by dt seconds and return a telemetry snapshot."""
        dt = max(0.0, min(float(dt), 0.1))
        current_time = self.elapsed_s if now is None else float(now)
        self.elapsed_s += dt
        current_time = max(current_time, self.elapsed_s)

        desired = self._controller_command(current_time)
        if not self.armed or self.failsafe_active:
            self._thrusters = (0.0, 0.0, 0.0, 0.0)
        elif dt > 0.0:
            delayed = self._delayed_command(current_time, desired)
            alpha = min(1.0, dt / self.RESPONSE_TAU_S)
            self._thrusters = tuple(
                self._clamp(actual + alpha * (target - actual))
                for actual, target in zip(self._thrusters, delayed)
            )

        surge_cmd, sway_cmd, heave_cmd, yaw_cmd = self._thrusters
        if dt > 0.0:
            # Linear thrust acceleration with viscous drag.
            self.surge_mps += (1.35 * surge_cmd - 0.85 * self.surge_mps) * dt
            self.sway_mps += (1.10 * sway_cmd - 0.95 * self.sway_mps) * dt
            self.heave_mps += (0.95 * heave_cmd - 1.10 * self.heave_mps) * dt
            self.yaw_rate_dps += (52.0 * yaw_cmd - 2.7 * self.yaw_rate_dps) * dt

            heading = math.radians(self.yaw_deg)
            body_north = self.surge_mps * math.cos(heading) - self.sway_mps * math.sin(heading)
            body_east = self.surge_mps * math.sin(heading) + self.sway_mps * math.cos(heading)
            if self.current_enabled:
                current_angle = math.radians(self.current_heading_deg)
                current_north = self.current_speed_mps * math.cos(current_angle)
                current_east = self.current_speed_mps * math.sin(current_angle)
            else:
                current_north = current_east = 0.0

            self.north_m += (body_north + current_north) * dt
            self.east_m += (body_east + current_east) * dt
            self.depth_m = max(0.0, min(self.MAX_DEPTH_M, self.depth_m + self.heave_mps * dt))
            self.yaw_deg = self._wrap_heading(self.yaw_deg + self.yaw_rate_dps * dt)

            roll_target = -8.0 * sway_cmd
            pitch_target = -7.0 * surge_cmd
            attitude_alpha = min(1.0, dt * 4.0)
            self.roll_deg += (roll_target - self.roll_deg) * attitude_alpha
            self.pitch_deg += (pitch_target - self.pitch_deg) * attitude_alpha

            mean_load = sum(abs(v) for v in self._thrusters) / 4.0
            self.battery_v = max(
                self.BATTERY_MIN_V,
                self.battery_v - (0.000025 + 0.004 * mean_load) * dt,
            )

        return self.telemetry()

    def telemetry(self) -> Telemetry:
        return Telemetry(
            elapsed_s=self.elapsed_s,
            armed=self.armed,
            mode=self.mode,
            roll_deg=self.roll_deg,
            pitch_deg=self.pitch_deg,
            yaw_deg=self.yaw_deg,
            depth_m=self.depth_m,
            battery_v=self.battery_v,
            north_m=self.north_m,
            east_m=self.east_m,
            surge_mps=self.surge_mps,
            sway_mps=self.sway_mps,
            heave_mps=self.heave_mps,
            yaw_rate_dps=self.yaw_rate_dps,
            target_depth_m=self.target_depth_m,
            target_heading_deg=self.target_heading_deg,
            thrusters=self._thrusters,
            failsafe_active=self.failsafe_active,
            current_enabled=self.current_enabled,
            current_speed_mps=self.current_speed_mps if self.current_enabled else 0.0,
            current_heading_deg=self.current_heading_deg,
        )
