"""OpenStreetMap tile canvas with an honest offline fallback.

Tiles are fetched only for the visible map viewport, cached on disk, and
requested with an identifying User-Agent. Network work happens on worker
threads; Tk widgets are touched only by the main thread.
"""
from __future__ import annotations

import math
import os
import time
from pathlib import Path
import threading
import tkinter as tk
from queue import SimpleQueue, Empty
from tkinter import ttk
from urllib.error import URLError, HTTPError
from urllib.request import Request, urlopen
from concurrent.futures import ThreadPoolExecutor, CancelledError
from typing import Callable

try:
    from PIL import Image, ImageDraw, ImageTk
except ImportError:  # pragma: no cover - surfaced as a clear UI fallback
    Image = ImageDraw = ImageTk = None  # type: ignore[assignment]

TILE_SIZE = 256
CACHE_TTL_S = 7 * 24 * 60 * 60
TILE_URL_TEMPLATE = os.environ.get(
    "ROV_OSM_TILE_URL", "https://tile.openstreetmap.org/{z}/{x}/{y}.png"
)
DEFAULT_LAT = 10.8
DEFAULT_LON = 74.4


def latlon_to_tile(lat: float, lon: float, zoom: int) -> tuple[float, float]:
    lat = max(-85.05112878, min(85.05112878, lat))
    n = 2.0 ** zoom
    x = (lon + 180.0) / 360.0 * n
    lat_rad = math.radians(lat)
    y = (1.0 - math.asinh(math.tan(lat_rad)) / math.pi) / 2.0 * n
    return x, y


class OSMMapView(tk.Frame):
    def __init__(self, parent: tk.Widget, **kwargs: object) -> None:
        super().__init__(parent, bg="#0d1b2a", **kwargs)
        self.zoom = 8
        self.center_lat = DEFAULT_LAT
        self.center_lon = DEFAULT_LON
        self.cache_dir = Path.home() / ".cache" / "coratia_rov_ground_station" / "osm"
        self.cache_dir.mkdir(parents=True, exist_ok=True)
        self.pool = ThreadPoolExecutor(max_workers=3, thread_name_prefix="osm-tile")
        self.pending: set[tuple[int, int, int]] = set()
        self.failed_until: dict[tuple[int, int, int], float] = {}
        self.tile_results: SimpleQueue[tuple[tuple[int, int, int], str | None]] = SimpleQueue()
        self.tile_images: dict[tuple[int, int, int], object] = {}
        self.photo_refs: list[object] = []
        self.status = "OSM TILE LAYER · CONNECTING"
        self.on_tiles_status: Callable[[str], None] | None = None
        self.track: list[tuple[float, float]] = []
        self._last_view_size = (0, 0)

        top = tk.Frame(self, bg="#0d1b2a")
        top.pack(fill="x", padx=12, pady=(10, 6))
        tk.Label(top, text="OPENSTREETMAP", bg="#0d1b2a", fg="#d9e8f5",
                 font=("DejaVu Sans", 9, "bold")).pack(side="left")
        self.status_label = tk.Label(top, text=self.status, bg="#0d1b2a", fg="#8aa0b8",
                                     font=("DejaVu Sans", 8, "bold"))
        self.status_label.pack(side="left", padx=(12, 0))
        controls = tk.Frame(top, bg="#0d1b2a")
        controls.pack(side="right")
        for symbol, delta in (("−", -1), ("+", 1)):
            tk.Button(controls, text=symbol, width=3, command=lambda d=delta: self.set_zoom(self.zoom + d),
                      bg="#172b3e", fg="#d9e8f5", activebackground="#21425b", activeforeground="white",
                      relief="flat", font=("DejaVu Sans", 10, "bold"), cursor="hand2").pack(side="left", padx=2)

        self.canvas = tk.Canvas(self, bg="#10283a", highlightthickness=0, height=320)
        self.canvas.pack(fill="both", expand=True, padx=10, pady=(0, 10))
        self.canvas.bind("<Configure>", lambda _e: self.redraw())
        self.canvas.bind("<Button-1>", self._recenter_click)
        self.after(600, self._poll_tiles)

    def set_status(self, status: str) -> None:
        self.status = status
        self.status_label.configure(text=status)
        if self.on_tiles_status:
            self.on_tiles_status(status)

    def set_zoom(self, zoom: int) -> None:
        self.zoom = max(3, min(17, int(zoom)))
        self.tile_images.clear()
        self.redraw()

    def set_vehicle_position(self, north_m: float, east_m: float) -> None:
        # A local tangent-plane approximation around the demonstration coordinate.
        lat = self.center_lat + north_m / 111_320.0
        lon_scale = max(0.15, math.cos(math.radians(self.center_lat)))
        lon = self.center_lon + east_m / (111_320.0 * lon_scale)
        if not self.track or math.hypot(lat - self.track[-1][0], lon - self.track[-1][1]) > 0.000003:
            self.track.append((lat, lon))
            self.track = self.track[-250:]
        self.redraw()

    def _recenter_click(self, event: tk.Event) -> None:
        width, height = max(1, self.canvas.winfo_width()), max(1, self.canvas.winfo_height())
        center_x, center_y = width / 2, height / 2
        dx = (event.x - center_x) / (TILE_SIZE * 2 ** (self.zoom - 8))
        dy = (event.y - center_y) / (TILE_SIZE * 2 ** (self.zoom - 8))
        x, y = latlon_to_tile(self.center_lat, self.center_lon, self.zoom)
        self.center_lat, self.center_lon = self._tile_to_latlon(x + dx, y + dy, self.zoom)
        self.track.clear()
        self.tile_images.clear()
        self.redraw()

    @staticmethod
    def _tile_to_latlon(x: float, y: float, zoom: int) -> tuple[float, float]:
        n = 2.0 ** zoom
        lon = x / n * 360.0 - 180.0
        lat_rad = math.atan(math.sinh(math.pi * (1 - 2 * y / n)))
        return math.degrees(lat_rad), lon

    def _tile_path(self, z: int, x: int, y: int) -> Path:
        return self.cache_dir / str(z) / str(x) / f"{y}.png"

    def _download_tile(self, key: tuple[int, int, int]) -> tuple[tuple[int, int, int], str | None]:
        z, x, y = key
        path = self._tile_path(z, x, y)
        if path.exists() and time.time() - path.stat().st_mtime < CACHE_TTL_S:
            return key, str(path)
        n = 2 ** z
        if y < 0 or y >= n:
            return key, None
        x_wrapped = x % n
        url = TILE_URL_TEMPLATE.format(z=z, x=x_wrapped, y=y)
        request = Request(url, headers={"User-Agent": "CoratiaROVGroundStation/1.0 (desktop assessment demo)"})
        try:
            with urlopen(request, timeout=4.5) as response:
                data = response.read()
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_bytes(data)
            return key, str(path)
        except (URLError, HTTPError, TimeoutError, OSError):
            return key, None

    def _queue_tile(self, key: tuple[int, int, int]) -> None:
        if key in self.pending or key in self.tile_images:
            return
        if self.failed_until.get(key, 0.0) > time.monotonic():
            return
        path = self._tile_path(*key)
        if path.exists() and time.time() - path.stat().st_mtime < CACHE_TTL_S:
            self._load_tile((key, str(path)))
            return
        self.pending.add(key)
        future = self.pool.submit(self._download_tile, key)
        future.add_done_callback(self._tile_future_done)

    def _tile_future_done(self, future: object) -> None:
        try:
            result = future.result()  # type: ignore[attr-defined]
        except (CancelledError, Exception):
            return
        self.tile_results.put(result)

    def _load_tile(self, result: tuple[tuple[int, int, int], str | None]) -> None:
        key, path = result
        self.pending.discard(key)
        if path is None:
            self.failed_until[key] = time.monotonic() + 60.0
        if path is None or Image is None or ImageTk is None:
            if not any(v is not None for v in self.tile_images.values()):
                self.set_status("OSM TILES OFFLINE · GRID PREVIEW")
            return
        try:
            image = Image.open(path).convert("RGB")
            self.tile_images[key] = ImageTk.PhotoImage(image)
            self.set_status("OSM LIVE")
            self.redraw()
        except Exception:
            self.set_status("OSM TILE CACHE ERROR")

    def redraw(self) -> None:
        if not hasattr(self, "canvas"):
            return
        self.canvas.delete("all")
        width, height = max(1, self.canvas.winfo_width()), max(1, self.canvas.winfo_height())
        cx, cy = width / 2, height / 2
        self.photo_refs = []
        center_tx, center_ty = latlon_to_tile(self.center_lat, self.center_lon, self.zoom)
        px_center_x = center_tx * TILE_SIZE
        px_center_y = center_ty * TILE_SIZE
        left_px, top_px = px_center_x - cx, px_center_y - cy
        first_x = math.floor(left_px / TILE_SIZE)
        last_x = math.floor((left_px + width) / TILE_SIZE)
        first_y = math.floor(top_px / TILE_SIZE)
        last_y = math.floor((top_px + height) / TILE_SIZE)
        have_tile = False
        for tile_x in range(first_x, last_x + 1):
            for tile_y in range(first_y, last_y + 1):
                key = (self.zoom, tile_x, tile_y)
                image = self.tile_images.get(key)
                x = tile_x * TILE_SIZE - left_px
                y = tile_y * TILE_SIZE - top_px
                if image is not None:
                    self.canvas.create_image(x, y, image=image, anchor="nw")
                    self.photo_refs.append(image)
                    have_tile = True
                else:
                    self._queue_tile(key)
        if not have_tile:
            self._draw_offline_grid(width, height)
        self._draw_track_and_vehicle(width, height, left_px, top_px)
        self.canvas.create_rectangle(8, height - 28, 300, height - 7, fill="#0a1724", outline="#29445b")
        self.canvas.create_text(16, height - 17, text=f"{self.center_lat:.4f}° N   {self.center_lon:.4f}° E   Z{self.zoom}",
                                fill="#c4d7e8", anchor="w", font=("DejaVu Sans Mono", 8, "bold"))
        self.canvas.create_text(width - 10, 10, text="SIMULATED POSITION", fill="#c4d7e8",
                                anchor="ne", font=("DejaVu Sans", 8, "bold"))
        self.canvas.create_text(width - 10, height - 17, text="© OpenStreetMap contributors",
                                fill="#e4edf4", anchor="e",
                                font=("DejaVu Sans", 8, "bold"))

    def _draw_offline_grid(self, width: int, height: int) -> None:
        self.canvas.create_rectangle(0, 0, width, height, fill="#122d3e", outline="")
        for x in range(0, width, 48):
            self.canvas.create_line(x, 0, x, height, fill="#234357", dash=(2, 6))
        for y in range(0, height, 48):
            self.canvas.create_line(0, y, width, y, fill="#234357", dash=(2, 6))
        # Subtle latitude/longitude guides keep the offline state readable as a map panel.
        self.canvas.create_line(width * 0.12, height * 0.24, width * 0.88, height * 0.24, fill="#31556a", dash=(5, 5))
        self.canvas.create_line(width * 0.12, height * 0.75, width * 0.88, height * 0.75, fill="#31556a", dash=(5, 5))
        self.canvas.create_text(width / 2, 28, text="MAP TILES REQUIRE AN INTERNET CONNECTION",
                                fill="#8eaabd", font=("DejaVu Sans", 9, "bold"))
        self.canvas.create_text(width / 2, height / 2 + 25, text="OSM TILE LAYER WILL LOAD HERE",
                                fill="#6f8da3", font=("DejaVu Sans", 11, "bold"))

    def _draw_track_and_vehicle(self, width: int, height: int, left_px: float, top_px: float) -> None:
        # Keep the ROV marker at the center of the current local map viewport.
        points: list[float] = []
        if len(self.track) >= 2:
            for lat, lon in self.track:
                tx, ty = latlon_to_tile(lat, lon, self.zoom)
                points.extend((tx * TILE_SIZE - left_px, ty * TILE_SIZE - top_px))
            self.canvas.create_line(*points, fill="#32d7eb", width=2, smooth=True)
        x, y = width / 2, height / 2
        self.canvas.create_oval(x - 12, y - 12, x + 12, y + 12, fill="#08202c", outline="#39e0ee", width=2)
        self.canvas.create_oval(x - 4, y - 4, x + 4, y + 4, fill="#39e0ee", outline="")
        self.canvas.create_text(x + 18, y - 14, text="ROV-01", fill="#f4fbff", anchor="w",
                                font=("DejaVu Sans", 8, "bold"))

    def _poll_tiles(self) -> None:
        if self.winfo_exists():
            updated = False
            while True:
                try:
                    result = self.tile_results.get_nowait()
                except Empty:
                    break
                self._load_tile(result)
                updated = True
            if updated:
                self.redraw()
            else:
                self.redraw()
            self.after(1000, self._poll_tiles)

    def close(self) -> None:
        self.pool.shutdown(wait=False, cancel_futures=True)
