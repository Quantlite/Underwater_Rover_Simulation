"""Native Tkinter desktop UI for the Coratia ROV telemetry assessment."""
from __future__ import annotations

from collections import deque
from datetime import datetime
import math
import os
import tkinter as tk
from tkinter import messagebox
import time
from typing import Deque

from .logger import TelemetryLogger
from .map_view import OSMMapView
from .simulator import Mode, ROVSimulator, Telemetry


BG = "#07111f"
PANEL = "#0d1b2a"
PANEL_ALT = "#102236"
BORDER = "#20364b"
TEXT = "#e6f0f8"
MUTED = "#8ba1b7"
CYAN = "#39d8ec"
GREEN = "#46d6a5"
AMBER = "#ffbd69"
RED = "#f06c74"
BLUE = "#5d9dff"
FONT = "DejaVu Sans"
MONO = "DejaVu Sans Mono"


class DepthPlot(tk.Canvas):
    def __init__(self, parent: tk.Widget, **kwargs: object) -> None:
        super().__init__(parent, bg=PANEL, highlightthickness=0, **kwargs)
        self.samples: Deque[tuple[float, float]] = deque(maxlen=180)
        self.target_depth = 2.4
        self.show_target = False
        self.bind("<Configure>", lambda _e: self.redraw())

    def add_sample(self, elapsed: float, depth: float, target: float, show_target: bool) -> None:
        self.samples.append((elapsed, depth))
        self.target_depth = target
        self.show_target = show_target
        self.redraw()

    def redraw(self) -> None:
        self.delete("all")
        w, h = max(1, self.winfo_width()), max(1, self.winfo_height())
        left, right, top, bottom = 52, w - 18, 16, h - 34
        if right <= left or bottom <= top:
            return
        data = list(self.samples)
        max_depth = max([3.0, self.target_depth + 0.8] + [d for _, d in data])
        max_depth = max(4.0, math.ceil(max_depth / 2.0) * 2.0)
        min_depth, max_y = 0.0, max_depth
        for i in range(5):
            y = top + (bottom - top) * i / 4
            depth = max_y * i / 4
            self.create_line(left, y, right, y, fill="#20364b", dash=(2, 5))
            self.create_text(left - 9, y, text=f"{depth:.0f}", fill=MUTED, anchor="e",
                             font=(MONO, 8))
        for i in range(6):
            x = left + (right - left) * i / 5
            self.create_line(x, top, x, bottom, fill="#172d40", dash=(1, 5))
        self.create_text(12, top + 3, text="DEPTH", fill=MUTED, anchor="nw", font=(FONT, 8, "bold"))
        self.create_text(12, top + 17, text="m ↓", fill=MUTED, anchor="nw", font=(FONT, 8))
        self.create_text(right, h - 12, text="TIME →", fill=MUTED, anchor="e", font=(FONT, 8, "bold"))

        if self.show_target:
            y = bottom - (self.target_depth / max_y) * (bottom - top)
            self.create_line(left, y, right, y, fill=AMBER, width=1, dash=(7, 4))
            self.create_text(right - 3, y - 9, text=f"TARGET {self.target_depth:.1f} m",
                             fill=AMBER, anchor="e", font=(MONO, 8, "bold"))
        if len(data) >= 2:
            first_t = data[0][0]
            last_t = max(data[-1][0], first_t + 1.0)
            coords: list[float] = []
            for elapsed, depth in data:
                x = left + (elapsed - first_t) / (last_t - first_t) * (right - left)
                y = bottom - (depth / max_y) * (bottom - top)
                coords.extend((x, y))
            self.create_line(*coords, fill=CYAN, width=2.2, smooth=True)
            x, y = coords[-2:]
            self.create_oval(x - 3, y - 3, x + 3, y + 3, fill=CYAN, outline="")
        elif data:
            elapsed, depth = data[-1]
            y = bottom - (depth / max_y) * (bottom - top)
            self.create_oval(right - 3, y - 3, right + 3, y + 3, fill=CYAN, outline="")
        self.create_text(left, h - 12, text="LIVE TELEMETRY · 5 HZ", fill=MUTED, anchor="w",
                         font=(MONO, 8))


class AttitudeIndicator(tk.Canvas):
    def __init__(self, parent: tk.Widget, **kwargs: object) -> None:
        super().__init__(parent, bg=PANEL, highlightthickness=0, **kwargs)
        self.roll = 0.0
        self.pitch = 0.0
        self.heading = 0.0
        self.bind("<Configure>", lambda _e: self.redraw())

    def update_values(self, roll: float, pitch: float, heading: float) -> None:
        self.roll, self.pitch, self.heading = roll, pitch, heading
        self.redraw()

    def redraw(self) -> None:
        self.delete("all")
        w, h = max(1, self.winfo_width()), max(1, self.winfo_height())
        cx, cy = w / 2, h / 2 - 3
        radius = min(w * 0.28, h * 0.38, 68)
        self.create_oval(cx - radius, cy - radius, cx + radius, cy + radius,
                         outline="#37556e", width=2)
        self.create_oval(cx - radius + 8, cy - radius + 8, cx + radius - 8, cy + radius - 8,
                         outline="#203e55")
        # Horizon line rotated by roll and shifted by pitch.
        angle = math.radians(self.roll)
        shift = max(-radius * 0.55, min(radius * 0.55, self.pitch * 1.8))
        dx, dy = math.cos(angle) * radius * 0.88, math.sin(angle) * radius * 0.88
        self.create_line(cx - dx, cy + shift - dy, cx + dx, cy + shift + dy,
                         fill=CYAN, width=2)
        self.create_line(cx - 19, cy, cx - 6, cy, fill=AMBER, width=2)
        self.create_line(cx + 6, cy, cx + 19, cy, fill=AMBER, width=2)
        self.create_oval(cx - 2, cy - 2, cx + 2, cy + 2, fill=AMBER, outline="")
        self.create_text(cx, cy + radius + 19, text=f"HDG {self.heading:05.1f}°",
                         fill=TEXT, font=(MONO, 9, "bold"))
        self.create_text(12, 12, text=f"R {self.roll:+.1f}°   P {self.pitch:+.1f}°",
                         fill=MUTED, anchor="nw", font=(MONO, 8))


class ThrusterBars(tk.Canvas):
    def __init__(self, parent: tk.Widget, **kwargs: object) -> None:
        super().__init__(parent, bg=PANEL, highlightthickness=0, **kwargs)
        self.values = (0.0, 0.0, 0.0, 0.0)
        self.labels = ("SURGE", "SWAY", "HEAVE", "YAW")
        self.bind("<Configure>", lambda _e: self.redraw())

    def update_values(self, values: tuple[float, float, float, float]) -> None:
        self.values = values
        self.redraw()

    def redraw(self) -> None:
        self.delete("all")
        w, h = max(1, self.winfo_width()), max(1, self.winfo_height())
        row_h = max(30, (h - 18) / 4)
        for i, (label, value) in enumerate(zip(self.labels, self.values)):
            y = 12 + i * row_h
            self.create_text(12, y + 7, text=label, fill=MUTED, anchor="w", font=(FONT, 8, "bold"))
            x0, x1 = 92, max(100, w - 56)
            mid = (x0 + x1) / 2
            self.create_line(x0, y + 8, x1, y + 8, fill="#20364b", width=7, capstyle="round")
            self.create_line(mid, y + 1, mid, y + 15, fill="#7d93a7", width=1)
            x = mid + max(-1.0, min(1.0, value)) * (x1 - x0) / 2
            color = GREEN if abs(value) < 0.01 else (CYAN if value >= 0 else AMBER)
            self.create_line(mid, y + 8, x, y + 8, fill=color, width=7, capstyle="round")
            self.create_text(w - 9, y + 7, text=f"{value:+.2f}", fill=TEXT,
                             anchor="e", font=(MONO, 8))


def make_panel(parent: tk.Widget, title: str, subtitle: str = "") -> tuple[tk.Frame, tk.Frame]:
    outer = tk.Frame(parent, bg=PANEL, highlightbackground=BORDER, highlightthickness=1)
    header = tk.Frame(outer, bg=PANEL)
    header.pack(fill="x", padx=14, pady=(10, 5))
    tk.Label(header, text=title, bg=PANEL, fg=TEXT, font=(FONT, 9, "bold")).pack(side="left")
    if subtitle:
        tk.Label(header, text=subtitle, bg=PANEL, fg=MUTED, font=(FONT, 8)).pack(side="right")
    body = tk.Frame(outer, bg=PANEL)
    body.pack(fill="both", expand=True, padx=10, pady=(0, 10))
    return outer, body


class ROVStationApp:
    def __init__(self, root: tk.Tk, demo: bool = False) -> None:
        self.root = root
        self.demo = demo
        self.sim = ROVSimulator()
        self.logger = TelemetryLogger(PathLikeLogs())
        self.pressed_keys: set[str] = set()
        self.last_tick = time.monotonic()
        self.last_refresh = 0.0
        self.last_chart_update = 0.0
        self.last_map_update = 0.0
        self.last_logged = 0.0
        self.last_failsafe_notice = False
        self.history_seeded = False
        self._metric_values: dict[str, tk.Label] = {}
        self._mode_buttons: dict[Mode, tk.Button] = {}
        self._build_ui()
        self._seed_chart()
        self._bind_keyboard()
        self._event("SIMULATOR INITIALIZED · HARDWARE NOT REQUIRED")
        self._event("SAFETY INTERLOCK ACTIVE · OUTPUTS ZERO WHILE DISARMED")
        self.root.protocol("WM_DELETE_WINDOW", self.close)
        self.root.after(20, self._tick)
        if self.demo:
            self._schedule_demo()

    def _build_ui(self) -> None:
        self.root.title("Coratia | ROV Telemetry Ground Station")
        self.root.geometry("1540x960")
        self.root.minsize(1180, 760)
        self.root.configure(bg=BG)
        if self.demo:
            self.root.configure(cursor="none")

        header = tk.Frame(self.root, bg="#091827", height=66, highlightbackground=BORDER, highlightthickness=0)
        header.pack(fill="x")
        header.pack_propagate(False)
        brand = tk.Frame(header, bg="#091827")
        brand.pack(side="left", padx=20, fill="y")
        mark = tk.Canvas(brand, width=36, height=36, bg="#091827", highlightthickness=0)
        mark.pack(side="left", pady=14)
        mark.create_oval(2, 2, 34, 34, outline=CYAN, width=2)
        mark.create_line(9, 18, 27, 18, fill=CYAN, width=2)
        mark.create_line(18, 9, 18, 27, fill=CYAN, width=2)
        brand_text = tk.Frame(brand, bg="#091827")
        brand_text.pack(side="left", padx=(10, 0), pady=12)
        tk.Label(brand_text, text="CORATIA", bg="#091827", fg=TEXT,
                 font=(FONT, 13, "bold")).pack(anchor="w")
        tk.Label(brand_text, text="ROV TELEMETRY GROUND STATION", bg="#091827", fg=MUTED,
                 font=(FONT, 8, "bold")).pack(anchor="w")

        header_right = tk.Frame(header, bg="#091827")
        header_right.pack(side="right", padx=20, fill="y")
        self.link_badge = tk.Label(header_right, text="●  SIM LINK ONLINE", bg="#0b2a2a", fg=GREEN,
                                   padx=12, pady=6, font=(FONT, 8, "bold"))
        self.link_badge.pack(side="left", pady=15, padx=(0, 12))
        self.header_mode = tk.Label(header_right, text="MODE  MANUAL", bg="#13283c", fg=CYAN,
                                    padx=12, pady=6, font=(FONT, 8, "bold"))
        self.header_mode.pack(side="left", pady=15)
        tk.Label(header_right, text="SIM / SITL  •  NO HARDWARE", bg="#091827", fg=MUTED,
                 font=(MONO, 8)).pack(side="left", padx=(14, 0))

        body = tk.Frame(self.root, bg=BG)
        body.pack(fill="both", expand=True, padx=12, pady=12)
        body.grid_columnconfigure(1, weight=1)
        body.grid_rowconfigure(0, weight=1)
        self.sidebar = tk.Frame(body, bg=PANEL, width=286, highlightbackground=BORDER, highlightthickness=1)
        self.sidebar.grid(row=0, column=0, sticky="nsw", padx=(0, 12))
        self.sidebar.grid_propagate(False)
        self.workspace = tk.Frame(body, bg=BG)
        self.workspace.grid(row=0, column=1, sticky="nsew")
        self.workspace.grid_columnconfigure(0, weight=1)
        self.workspace.grid_rowconfigure(1, weight=3)
        self.workspace.grid_rowconfigure(2, weight=2)

        self._build_sidebar()
        self._build_workspace()

    def _build_sidebar(self) -> None:
        s = self.sidebar
        tk.Label(s, text="VEHICLE CONTROL", bg=PANEL, fg=MUTED,
                 font=(FONT, 8, "bold")).pack(anchor="w", padx=16, pady=(16, 4))
        vehicle = tk.Frame(s, bg=PANEL_ALT, highlightbackground=BORDER, highlightthickness=1)
        vehicle.pack(fill="x", padx=12, pady=(0, 12))
        tk.Label(vehicle, text="ROV-01", bg=PANEL_ALT, fg=TEXT,
                 font=(FONT, 14, "bold")).pack(anchor="w", padx=12, pady=(10, 0))
        tk.Label(vehicle, text="MICRO-CLASS  /  4-AXIS MODEL", bg=PANEL_ALT, fg=MUTED,
                 font=(FONT, 7, "bold")).pack(anchor="w", padx=12, pady=(0, 8))
        self.arm_state = tk.Label(vehicle, text="●  DISARMED", bg="#351d29", fg=RED,
                                  font=(FONT, 9, "bold"), padx=10, pady=7)
        self.arm_state.pack(fill="x", padx=10, pady=(0, 10))

        arm_row = tk.Frame(s, bg=PANEL)
        arm_row.pack(fill="x", padx=12, pady=(0, 12))
        self.arm_button = tk.Button(arm_row, text="ARM VEHICLE", command=self._toggle_arm,
                                    bg="#0e473f", fg=GREEN, activebackground="#145d51", activeforeground="white",
                                    relief="flat", font=(FONT, 9, "bold"), cursor="hand2", pady=10)
        self.arm_button.pack(side="left", fill="x", expand=True, padx=(0, 5))
        self.estop_button = tk.Button(arm_row, text="E-STOP", command=self._emergency_stop,
                                      bg="#512530", fg="#ff9aa1", activebackground="#71323e",
                                      activeforeground="white", relief="flat", font=(FONT, 9, "bold"),
                                      cursor="hand2", pady=10)
        self.estop_button.pack(side="left", fill="x", expand=True, padx=(5, 0))

        self._section(s, "FLIGHT MODE")
        mode_frame = tk.Frame(s, bg=PANEL)
        mode_frame.pack(fill="x", padx=12, pady=(0, 12))
        for mode, label in ((Mode.MANUAL, "MANUAL"), (Mode.DEPTH_HOLD, "DEPTH HOLD"),
                            (Mode.HEADING_HOLD, "HEADING HOLD")):
            button = tk.Button(mode_frame, text=label, command=lambda m=mode: self._set_mode(m),
                               bg="#15283b", fg=MUTED, activebackground="#1e3b53", activeforeground=TEXT,
                               relief="flat", font=(FONT, 8, "bold"), cursor="hand2", pady=8)
            button.pack(fill="x", pady=2)
            self._mode_buttons[mode] = button
        self._update_mode_buttons()

        self._section(s, "HOLD TARGETS")
        targets = tk.Frame(s, bg=PANEL)
        targets.pack(fill="x", padx=12, pady=(0, 10))
        self.depth_entry = self._target_field(targets, "TARGET DEPTH", "2.4", "m")
        self.depth_apply = tk.Button(targets, text="SET DEPTH", command=self._apply_depth,
                                      bg="#173b4b", fg=CYAN, activebackground="#20576b", activeforeground="white",
                                      relief="flat", font=(FONT, 8, "bold"), pady=7, cursor="hand2")
        self.depth_apply.pack(fill="x", pady=(3, 8))
        self.heading_entry = self._target_field(targets, "TARGET HEADING", "276", "°")
        self.heading_apply = tk.Button(targets, text="SET HEADING", command=self._apply_heading,
                                       bg="#173b4b", fg=CYAN, activebackground="#20576b", activeforeground="white",
                                       relief="flat", font=(FONT, 8, "bold"), pady=7, cursor="hand2")
        self.heading_apply.pack(fill="x", pady=(3, 2))

        self._section(s, "MANUAL CONTROL  /  KEYBOARD")
        keys = tk.Frame(s, bg=PANEL_ALT, highlightbackground=BORDER, highlightthickness=1)
        keys.pack(fill="x", padx=12, pady=(0, 8))
        tk.Label(keys, text="W / S  SURGE     A / D  SWAY", bg=PANEL_ALT, fg=TEXT,
                 font=(MONO, 8, "bold")).pack(anchor="w", padx=10, pady=(9, 3))
        tk.Label(keys, text="R / F  HEAVE     Q / E  YAW", bg=PANEL_ALT, fg=TEXT,
                 font=(MONO, 8, "bold")).pack(anchor="w", padx=10, pady=3)
        tk.Label(keys, text="SPACE  NEUTRAL   ·   RELEASE TO STOP", bg=PANEL_ALT, fg=MUTED,
                 font=(MONO, 7)).pack(anchor="w", padx=10, pady=(3, 9))

        options = tk.Frame(s, bg=PANEL)
        options.pack(fill="x", padx=12, pady=(0, 10))
        self.current_var = tk.BooleanVar(value=True)
        tk.Checkbutton(options, text="Simulated water current", variable=self.current_var,
                       command=self._toggle_current, bg=PANEL, fg=TEXT, selectcolor=PANEL_ALT,
                       activebackground=PANEL, activeforeground=TEXT, font=(FONT, 8),
                       highlightthickness=0).pack(anchor="w")
        self.log_button = tk.Button(options, text="●  START CSV LOG", command=self._toggle_logging,
                                    bg="#172b3e", fg=AMBER, activebackground="#27435b",
                                    activeforeground="white", relief="flat", font=(FONT, 8, "bold"),
                                    cursor="hand2", pady=8)
        self.log_button.pack(fill="x", pady=(8, 0))
        tk.Label(s, text="SIMULATION ONLY  ·  NO HARDWARE OUTPUT", bg=PANEL, fg=MUTED,
                 font=(FONT, 7, "bold"), wraplength=245, justify="left").pack(anchor="w", padx=15, pady=(3, 12))

    def _section(self, parent: tk.Widget, title: str) -> None:
        tk.Label(parent, text=title, bg=PANEL, fg=MUTED, font=(FONT, 8, "bold")).pack(
            anchor="w", padx=16, pady=(3, 6)
        )

    def _target_field(self, parent: tk.Widget, label: str, value: str, unit: str) -> tk.Entry:
        row = tk.Frame(parent, bg=PANEL)
        row.pack(fill="x")
        tk.Label(row, text=label, bg=PANEL, fg=MUTED, font=(FONT, 7, "bold")).pack(side="left")
        tk.Label(row, text=unit, bg=PANEL, fg=MUTED, font=(FONT, 8)).pack(side="right")
        entry = tk.Entry(parent, bg="#081725", fg=TEXT, insertbackground=CYAN, relief="flat",
                         highlightthickness=1, highlightbackground=BORDER, highlightcolor=CYAN,
                         font=(MONO, 10), justify="left")
        entry.insert(0, value)
        entry.pack(fill="x", pady=(4, 1), ipady=6)
        return entry

    def _build_workspace(self) -> None:
        w = self.workspace
        metrics = tk.Frame(w, bg=BG)
        metrics.grid(row=0, column=0, sticky="ew", pady=(0, 10))
        for i in range(5):
            metrics.grid_columnconfigure(i, weight=1, uniform="metric")
        self._metric_card(metrics, 0, "DEPTH", "2.40", "m", CYAN)
        self._metric_card(metrics, 1, "HEADING", "276.0", "deg", BLUE)
        self._metric_card(metrics, 2, "ROLL", "+0.0", "deg", AMBER)
        self._metric_card(metrics, 3, "PITCH", "+0.0", "deg", AMBER)
        self._metric_card(metrics, 4, "BATTERY", "16.80", "V", GREEN)

        upper = tk.Frame(w, bg=BG)
        upper.grid(row=1, column=0, sticky="nsew", pady=(0, 10))
        upper.grid_columnconfigure(0, weight=1, uniform="upper")
        upper.grid_columnconfigure(1, weight=1, uniform="upper")
        upper.grid_rowconfigure(0, weight=1)
        chart_panel, chart_body = make_panel(upper, "DEPTH vs TIME", "LIVE · m")
        chart_panel.grid(row=0, column=0, sticky="nsew", padx=(0, 5))
        self.depth_plot = DepthPlot(chart_body)
        self.depth_plot.pack(fill="both", expand=True)
        map_panel, map_body = make_panel(upper, "POSITION / MAP", "OPENSTREETMAP")
        map_panel.grid(row=0, column=1, sticky="nsew", padx=(5, 0))
        self.map_view = OSMMapView(map_body)
        self.map_view.pack(fill="both", expand=True)

        lower = tk.Frame(w, bg=BG)
        lower.grid(row=2, column=0, sticky="nsew", pady=(0, 10))
        lower.grid_columnconfigure(0, weight=1, uniform="lower")
        lower.grid_columnconfigure(1, weight=1, uniform="lower")
        lower.grid_columnconfigure(2, weight=1, uniform="lower")
        lower.grid_rowconfigure(0, weight=1)
        attitude_panel, attitude_body = make_panel(lower, "ATTITUDE INDICATOR", "ROLL / PITCH / YAW")
        attitude_panel.grid(row=0, column=0, sticky="nsew", padx=(0, 5))
        self.attitude = AttitudeIndicator(attitude_body)
        self.attitude.pack(fill="both", expand=True)
        thrust_panel, thrust_body = make_panel(lower, "THRUSTER OUTPUT", "-1.00 TO +1.00")
        thrust_panel.grid(row=0, column=1, sticky="nsew", padx=5)
        self.thruster_bars = ThrusterBars(thrust_body)
        self.thruster_bars.pack(fill="both", expand=True)
        log_panel, log_body = make_panel(lower, "FLIGHT EVENT LOG", "LATEST EVENTS")
        log_panel.grid(row=0, column=2, sticky="nsew", padx=(5, 0))
        self.event_text = tk.Text(log_body, bg=PANEL, fg=MUTED, insertbackground=TEXT,
                                  relief="flat", wrap="word", height=8, font=(MONO, 7),
                                  state="disabled", padx=5, pady=3)
        self.event_text.pack(fill="both", expand=True)

        status = tk.Frame(w, bg="#0a1928", highlightbackground=BORDER, highlightthickness=1)
        status.grid(row=3, column=0, sticky="ew")
        self.status_left = tk.Label(status, text="SIM ENGINE 50 HZ  ·  MODEL: 4-AXIS / LINEAR DRAG",
                                    bg="#0a1928", fg=MUTED, font=(MONO, 7, "bold"))
        self.status_left.pack(side="left", padx=10, pady=7)
        self.status_right = tk.Label(status, text="FAILSAFE READY  ·  CSV OFF", bg="#0a1928", fg=GREEN,
                                     font=(MONO, 7, "bold"))
        self.status_right.pack(side="right", padx=10, pady=7)

    def _metric_card(self, parent: tk.Widget, column: int, title: str, value: str, unit: str, accent: str) -> None:
        card = tk.Frame(parent, bg=PANEL, highlightbackground=BORDER, highlightthickness=1)
        card.grid(row=0, column=column, sticky="nsew", padx=(0 if column == 0 else 5, 0 if column == 4 else 5))
        tk.Label(card, text=title, bg=PANEL, fg=MUTED, font=(FONT, 8, "bold")).pack(anchor="w", padx=12, pady=(8, 2))
        row = tk.Frame(card, bg=PANEL)
        row.pack(anchor="w", padx=12, pady=(0, 8))
        value_label = tk.Label(row, text=value, bg=PANEL, fg=accent, font=(MONO, 17, "bold"))
        value_label.pack(side="left")
        tk.Label(row, text=f" {unit}", bg=PANEL, fg=MUTED, font=(FONT, 8)).pack(side="left", pady=(6, 0))
        self._metric_values[title] = value_label

    def _seed_chart(self) -> None:
        now = 0.0
        for i in range(50):
            t = now + i * 0.4
            depth = 2.4 + 0.05 * math.sin(i / 5.5) + 0.02 * math.sin(i / 2.8)
            self.depth_plot.samples.append((t, depth))
        self.depth_plot.redraw()

    def _bind_keyboard(self) -> None:
        self.root.bind_all("<KeyPress>", self._on_key_press)
        self.root.bind_all("<KeyRelease>", self._on_key_release)
        self.root.bind_all("<FocusOut>", self._on_focus_out)

    def _on_key_press(self, event: tk.Event) -> None:
        focused = self.root.focus_get()
        if isinstance(focused, (tk.Entry, tk.Text)):
            return
        key = str(event.keysym).lower()
        if key in {"w", "s", "a", "d", "r", "f", "q", "e", "space"}:
            self.pressed_keys.add(key)
            self._send_keyboard_command()

    def _on_key_release(self, event: tk.Event) -> None:
        key = str(event.keysym).lower()
        if key in self.pressed_keys:
            self.pressed_keys.discard(key)
            self._send_keyboard_command()

    def _on_focus_out(self, _event: tk.Event) -> None:
        # Prevent a held-key command from remaining latched after the app loses focus.
        if self.pressed_keys:
            self.pressed_keys.clear()
            self._send_keyboard_command()

    def _send_keyboard_command(self) -> None:
        if not self.sim.armed or self.sim.mode != Mode.MANUAL:
            return
        keys = self.pressed_keys
        if "space" in keys:
            command = (0.0, 0.0, 0.0, 0.0)
        else:
            command = (
                float("w" in keys) - float("s" in keys),
                float("d" in keys) - float("a" in keys),
                float("r" in keys) - float("f" in keys),
                float("e" in keys) - float("q" in keys),
            )
        self.sim.set_manual_input(*command, now=self.sim.elapsed_s)

    def _set_mode(self, mode: Mode) -> None:
        self.sim.set_mode(mode, now=self.sim.elapsed_s)
        self._event(f"FLIGHT MODE CHANGED · {mode.value}")
        self.header_mode.configure(text=f"MODE  {mode.value}")
        self._update_mode_buttons()
        self._send_keyboard_command()

    def _update_mode_buttons(self) -> None:
        for mode, button in self._mode_buttons.items():
            if self.sim.mode == mode:
                button.configure(bg="#174356", fg=CYAN, activebackground="#205b72")
            else:
                button.configure(bg="#15283b", fg=MUTED, activebackground="#1e3b53")

    def _toggle_arm(self) -> None:
        if self.sim.armed:
            self.sim.disarm()
            self.pressed_keys.clear()
            self._event("VEHICLE DISARMED · ALL THRUST ZERO")
        else:
            ok, message = self.sim.arm(now=self.sim.elapsed_s)
            self._event(message.upper())
            if not ok:
                messagebox.showwarning("Arm blocked", message, parent=self.root)
        self._update_arm_ui()

    def _emergency_stop(self) -> None:
        self.sim.disarm()
        self.pressed_keys.clear()
        self._event("EMERGENCY STOP · DISARMED · THRUST CUT IMMEDIATELY")
        self._update_arm_ui()

    def _update_arm_ui(self) -> None:
        if self.sim.armed:
            self.arm_state.configure(text="●  ARMED", bg="#0d3b37", fg=GREEN)
            self.arm_button.configure(text="DISARM VEHICLE", bg="#452934", fg="#ff9aa1")
        else:
            self.arm_state.configure(text="●  DISARMED", bg="#351d29", fg=RED)
            self.arm_button.configure(text="ARM VEHICLE", bg="#0e473f", fg=GREEN)

    def _apply_depth(self) -> None:
        try:
            target = float(self.depth_entry.get().strip())
            if self.sim.mode != Mode.DEPTH_HOLD:
                self._set_mode(Mode.DEPTH_HOLD)
            self.sim.set_target_depth(target)
            self._event(f"DEPTH TARGET SET · {self.sim.target_depth_m:.2f} m")
        except (ValueError, TypeError) as exc:
            messagebox.showerror("Invalid depth", str(exc), parent=self.root)

    def _apply_heading(self) -> None:
        try:
            target = float(self.heading_entry.get().strip())
            if self.sim.mode != Mode.HEADING_HOLD:
                self._set_mode(Mode.HEADING_HOLD)
            self.sim.set_target_heading(target)
            self._event(f"HEADING TARGET SET · {self.sim.target_heading_deg:.1f}°")
        except (ValueError, TypeError) as exc:
            messagebox.showerror("Invalid heading", str(exc), parent=self.root)

    def _toggle_current(self) -> None:
        self.sim.set_current(self.current_var.get())
        self._event("WATER CURRENT ENABLED" if self.current_var.get() else "WATER CURRENT DISABLED")

    def _toggle_logging(self) -> None:
        if self.logger.active:
            self.logger.stop()
            self.log_button.configure(text="●  START CSV LOG", fg=AMBER)
            self._event(f"CSV LOG STOPPED · {self.logger.path.name if self.logger.path else ''}")
        else:
            path = self.logger.start()
            self.log_button.configure(text="■  STOP CSV LOG", fg=RED)
            self._event(f"CSV LOGGING STARTED · {path.name}")

    def _event(self, message: str) -> None:
        stamp = datetime.now().strftime("%H:%M:%S")
        if not hasattr(self, "event_text"):
            return
        self.event_text.configure(state="normal")
        self.event_text.insert("end", f"{stamp}  {message}\n")
        lines = int(self.event_text.index("end-1c").split(".")[0])
        if lines > 45:
            self.event_text.delete("1.0", "6.0")
        self.event_text.see("end")
        self.event_text.configure(state="disabled")

    def _tick(self) -> None:
        if not self.root.winfo_exists():
            return
        now = time.monotonic()
        dt = min(0.1, max(0.001, now - self.last_tick))
        self.last_tick = now
        telemetry = self.sim.step(dt, now=self.sim.elapsed_s + dt)

        if telemetry.failsafe_active and not self.last_failsafe_notice:
            self._event("MANUAL WATCHDOG · NO INPUT FOR 1.0 s · THRUST ZERO")
        self.last_failsafe_notice = telemetry.failsafe_active

        if telemetry.elapsed_s - self.last_chart_update >= 0.2:
            self.depth_plot.add_sample(
                telemetry.elapsed_s, telemetry.depth_m, telemetry.target_depth_m,
                telemetry.mode == Mode.DEPTH_HOLD,
            )
            self.last_chart_update = telemetry.elapsed_s
        if telemetry.elapsed_s - self.last_refresh >= 0.1:
            self._refresh_dashboard(telemetry)
            self.last_refresh = telemetry.elapsed_s
        if telemetry.elapsed_s - self.last_map_update >= 1.0:
            self.map_view.set_vehicle_position(telemetry.north_m, telemetry.east_m)
            self.last_map_update = telemetry.elapsed_s
        if telemetry.elapsed_s - self.last_logged >= 0.1:
            self.logger.log(telemetry)
            self.last_logged = telemetry.elapsed_s
        self.root.after(20, self._tick)

    def _refresh_dashboard(self, t: Telemetry) -> None:
        self._metric_values["DEPTH"].configure(text=f"{t.depth_m:0.2f}")
        self._metric_values["HEADING"].configure(text=f"{t.yaw_deg:05.1f}")
        self._metric_values["ROLL"].configure(text=f"{t.roll_deg:+.1f}")
        self._metric_values["PITCH"].configure(text=f"{t.pitch_deg:+.1f}")
        self._metric_values["BATTERY"].configure(text=f"{t.battery_v:.2f}")
        self.header_mode.configure(text=f"MODE  {t.mode.value}")
        self._update_arm_ui()
        self.attitude.update_values(t.roll_deg, t.pitch_deg, t.yaw_deg)
        self.thruster_bars.update_values(t.thrusters)
        if t.failsafe_active:
            self.status_right.configure(text="MANUAL WATCHDOG ACTIVE  ·  THRUST ZERO", fg=AMBER)
        elif self.logger.active:
            self.status_right.configure(text="FAILSAFE READY  ·  CSV RECORDING", fg=GREEN)
        else:
            self.status_right.configure(text="FAILSAFE READY  ·  CSV OFF", fg=GREEN)

    def _schedule_demo(self) -> None:
        """Predictable UI-only sequence used to capture the assessment video."""
        self.root.after(1200, self._demo_arm)
        self.root.after(3000, lambda: self._demo_depth_hold())
        self.root.after(7000, lambda: self._demo_heading_hold())
        self.root.after(11000, lambda: self._demo_manual())
        self.root.after(11500, self._demo_drive)
        self.root.after(15500, lambda: self._demo_stop_drive())
        self.root.after(18000, self._demo_depth_hold)
        self.root.after(24000, lambda: self._demo_finish())

    def _demo_arm(self) -> None:
        if not self.sim.armed:
            self._toggle_arm()

    def _demo_depth_hold(self) -> None:
        self._set_mode(Mode.DEPTH_HOLD)
        self.depth_entry.delete(0, "end")
        self.depth_entry.insert(0, "3.6")
        self.sim.set_target_depth(3.6)
        self._event("DEPTH TARGET SET · 3.60 m")

    def _demo_heading_hold(self) -> None:
        self._set_mode(Mode.HEADING_HOLD)
        self.heading_entry.delete(0, "end")
        self.heading_entry.insert(0, "112")
        self.sim.set_target_heading(112)
        self._event("HEADING TARGET SET · 112.0°")

    def _demo_manual(self) -> None:
        self._set_mode(Mode.MANUAL)

    def _demo_drive(self) -> None:
        if self.sim.armed and self.sim.mode == Mode.MANUAL:
            self.sim.set_manual_input(surge=0.55, sway=0.25, now=self.sim.elapsed_s)
            self._event("DEMO INPUT · SURGE +0.55 / SWAY +0.25")

    def _demo_stop_drive(self) -> None:
        self.sim.set_manual_input(now=self.sim.elapsed_s)
        self._event("DEMO INPUT RELEASED · NEUTRAL COMMAND")

    def _demo_finish(self) -> None:
        self._demo_depth_hold()
        self._event("DEMO WALKTHROUGH · HOLD TARGETS AND LIVE TELEMETRY")

    def close(self) -> None:
        try:
            self.logger.stop()
            self.map_view.close()
        finally:
            self.root.destroy()


def PathLikeLogs() -> str:
    # Keep generated CSV files next to the app when run from the project root.
    return os.environ.get("ROV_LOG_DIR", "logs")


def launch(demo: bool = False) -> None:
    root = tk.Tk()
    ROVStationApp(root, demo=demo)
    root.mainloop()
