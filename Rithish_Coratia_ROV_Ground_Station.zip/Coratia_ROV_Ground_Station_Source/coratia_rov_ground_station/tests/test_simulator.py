import math
import pytest

from rov_ground_station.simulator import Mode, ROVSimulator


def advance(sim: ROVSimulator, seconds: float, dt: float = 0.02) -> None:
    count = int(seconds / dt)
    for _ in range(count):
        sim.step(dt, now=sim.elapsed_s + dt)


def test_disarmed_thrust_is_always_zero():
    sim = ROVSimulator()
    sim.set_manual_input(surge=1.0, sway=-1.0, heave=0.5, yaw=1.0, now=0.0)
    advance(sim, 0.5)
    assert not sim.armed
    assert sim.thrusters == (0.0, 0.0, 0.0, 0.0)


def test_manual_command_responds_after_short_delay():
    sim = ROVSimulator()
    ok, _ = sim.arm(now=0.0)
    assert ok
    sim.set_manual_input(surge=1.0, now=sim.elapsed_s)
    advance(sim, 0.10)
    assert sim.thrusters[0] == pytest.approx(0.0, abs=1e-6)
    advance(sim, 0.30)
    assert sim.thrusters[0] > 0.7
    assert sim.surge_mps > 0.0


def test_manual_watchdog_cuts_thrust_after_one_second():
    sim = ROVSimulator()
    sim.arm(now=0.0)
    sim.set_manual_input(surge=1.0, now=0.0)
    advance(sim, 0.60)
    assert sim.thrusters[0] > 0.5
    advance(sim, 0.42)
    assert sim.failsafe_active
    assert sim.thrusters == (0.0, 0.0, 0.0, 0.0)


def test_disarm_cuts_thrust_immediately():
    sim = ROVSimulator()
    sim.arm(now=0.0)
    sim.set_manual_input(surge=1.0, now=0.0)
    advance(sim, 0.5)
    assert sim.thrusters[0] > 0.0
    sim.disarm()
    assert sim.thrusters == (0.0, 0.0, 0.0, 0.0)
    sim.step(0.02, now=sim.elapsed_s + 0.02)
    assert sim.thrusters == (0.0, 0.0, 0.0, 0.0)


def test_depth_hold_moves_toward_target_depth():
    sim = ROVSimulator()
    sim.arm(now=0.0)
    sim.set_mode(Mode.DEPTH_HOLD, now=0.0)
    sim.set_target_depth(3.5)
    starting_depth = sim.depth_m
    advance(sim, 3.0)
    assert sim.depth_m > starting_depth
    assert sim.depth_m < 3.7


def test_heading_hold_uses_shortest_turn_direction():
    sim = ROVSimulator()
    sim.yaw_deg = 350.0
    sim.arm(now=0.0)
    sim.set_mode(Mode.HEADING_HOLD, now=0.0)
    sim.set_target_heading(10.0)
    advance(sim, 1.0)
    assert sim.yaw_deg > 350.0 or sim.yaw_deg < 10.0
    assert sim.heading_error(10.0, 350.0) == pytest.approx(20.0)


def test_target_bounds_and_heading_wrap():
    sim = ROVSimulator()
    with pytest.raises(ValueError):
        sim.set_target_depth(-0.1)
    with pytest.raises(ValueError):
        sim.set_target_depth(51.0)
    sim.set_target_heading(725.0)
    assert sim.target_heading_deg == pytest.approx(5.0)


def test_current_can_be_disabled():
    sim = ROVSimulator()
    sim.set_current(False)
    before = sim.north_m, sim.east_m
    advance(sim, 1.0)
    assert (sim.north_m, sim.east_m) == pytest.approx(before)
