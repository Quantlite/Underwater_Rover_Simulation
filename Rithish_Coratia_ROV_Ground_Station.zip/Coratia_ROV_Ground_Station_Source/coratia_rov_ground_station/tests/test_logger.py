import csv

from rov_ground_station.logger import TelemetryLogger
from rov_ground_station.simulator import ROVSimulator


def test_csv_logger_writes_telemetry(tmp_path):
    sim = ROVSimulator()
    logger = TelemetryLogger(tmp_path)
    path = logger.start()
    sim.arm(now=0.0)
    sim.step(0.02, now=0.02)
    logger.log(sim.telemetry())
    logger.stop()

    assert path.exists()
    with path.open(newline="", encoding="utf-8") as handle:
        rows = list(csv.DictReader(handle))
    assert len(rows) == 1
    assert rows[0]["mode"] == "MANUAL"
    assert float(rows[0]["depth_m"]) >= 0.0
    assert "thruster_surge" in rows[0]
