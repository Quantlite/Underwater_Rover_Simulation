# Coratia Assessment Submission Checklist

- [ ] Reply to the original email thread (do not start a new email) to confirm participation within 24 hours of receipt. The invitation was timestamped 11 November 2026 at 13:25, so the 24-hour point is approximately **12 November 2026 at 13:25 IST**.
- [ ] Run the app on the submission laptop and check that the OpenStreetMap panel status reads **OSM LIVE**. If it still says offline, check internet access and tile access before recording.
- [ ] Record a fresh walkthrough so the video visibly contains the live OSM map, live telemetry, the depth plot, all three modes, and the target inputs.
- [ ] Attach `Coratia_ROV_Ground_Station_Source.zip` (or provide a cloud-storage link with both viewing and download access).
- [ ] Attach the walkthrough MP4.
- [ ] Submit by **Friday, 13 November 2026, before 1:30 PM IST**.
- [ ] Keep the source and interview notes available for the **Saturday, 14 November 2026** interview. Be ready to explain the simulator, watchdog, hold controllers, map tile handling, and CSV logger.
