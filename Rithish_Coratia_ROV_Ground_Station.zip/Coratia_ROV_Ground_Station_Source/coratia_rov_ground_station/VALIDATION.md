# Build and Validation Notes

Validated in the build environment on 11 November 2026.

| Check | Result |
|---|---|
| Python bytecode compilation (`python3 -m compileall -q .`) | Passed |
| Automated unit tests (`python3 -m pytest -q`) | 9 passed |
| Tkinter dashboard launch under Xvfb | Passed |
| Scripted Manual / Depth Hold / Heading Hold / Manual / Depth Hold UI walkthrough | Captured as `Coratia_ROV_Walkthrough.mp4` |
| Live OpenStreetMap tile download | Not verifiable in this build environment because outbound DNS/network access was unavailable |

The application contains the live OSM tile download and cache path, but the supplied video therefore shows the explicitly labelled offline grid preview. Run the app on an internet-connected machine and confirm the map status reads **OSM LIVE** before making the final assessment recording.
