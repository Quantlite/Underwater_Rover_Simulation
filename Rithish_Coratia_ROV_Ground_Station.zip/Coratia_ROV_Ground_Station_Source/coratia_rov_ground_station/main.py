"""Convenience entry point. Run: python main.py"""
from rov_ground_station.__main__ import main

if __name__ == "__main__":
    main()
